// server.js - Complete Express server with SQL Server connection
const express = require('express');
const sql = require('mssql');
const multer = require('multer');
const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');
const morgan = require('morgan');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Set up middleware
app.use(cors()); // Enable CORS for all routes
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(morgan('dev')); // Logging middleware
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max file size
    fileFilter: (req, file, cb) => {
        // Check file type
        const filetypes = /xlsx|xls/;
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = filetypes.test(file.mimetype);

        if (extname && mimetype) {
            cb(null, true);
        } else {
            cb(new Error('Only Excel files are allowed!'));
        }
    }
});

// Database configuration
const dbConfig = {
    server: 'localhost\\SQLEXPRESS', // Replace with your SQL Server instance
    database: 'SouthernCompany', // Database name
    options: {
        trustServerCertificate: true,
        enableArithAbort: true,
        encrypt: false,
        trustedConnection: true,
        integratedSecurity: true,
        connectTimeout: 30000
    }
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000
    }
};

// Initialize database
async function initDatabase() {
    try {
        // Connect to master database
        let pool = await sql.connect({
            ...dbConfig,
            database: 'master'
        });

        // Check if SouthernCompany database exists, create if not
        const result = await pool.request().query(`
      IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'SouthernCompany')
      BEGIN
        CREATE DATABASE SouthernCompany;
      END
    `);

        // Close connection to master
        await pool.close();

        // Connect to SouthernCompany database
        pool = await sql.connect(dbConfig);

        // Create tables if they don't exist
        await pool.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ChangeData]') AND type in (N'U'))
      BEGIN
        CREATE TABLE [dbo].[ChangeData] (
          [ChangeID] NVARCHAR(20) PRIMARY KEY,
          [Summary] NVARCHAR(500),
          [Priority] NVARCHAR(50),
          [StatusReason] NVARCHAR(50),
          [Impact] NVARCHAR(50),
          [ChangePlanning] NVARCHAR(50),
          [Submitter] NVARCHAR(50),
          [Coordinator] NVARCHAR(50),
          [SubmitDateTime] DATETIME,
          [SchStartDateTime] DATETIME,
          [SchEndDateTime] DATETIME,
          [ActualStartDateTime] DATETIME,
          [ActualEndDateTime] DATETIME,
          [CompletedDateTime] DATETIME,
          [ClosedDateTime] DATETIME,
          [CompletedYear] NVARCHAR(10),
          [CompletedMonth] NVARCHAR(10),
          [ChangeSuccess] NVARCHAR(50),
          [ProdCat2] NVARCHAR(100),
          [ProdCat3] NVARCHAR(100),
          [OpCat1] NVARCHAR(50),
          [OpCat2] NVARCHAR(50),
          [Customer] NVARCHAR(50),
          [CustomerOpco] NVARCHAR(50),
          [CustomerGroup] NVARCHAR(100),
          [CustomerDept] NVARCHAR(100),
          [ApprovalDateTime] DATETIME,
          [SchForAppDateTime] DATETIME,
          [ImpInProgDateTime] DATETIME,
          [LastModifiedDate] DATETIME,
          [CompletedYearQtr] NVARCHAR(10),
          [ClosedMonth] NVARCHAR(10),
          [ClosedYearQtr] NVARCHAR(10)
        );
      END

      IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Glossary]') AND type in (N'U'))
      BEGIN
        CREATE TABLE [dbo].[Glossary] (
          [Verbiage] NVARCHAR(100) PRIMARY KEY,
          [Meaning] NVARCHAR(500)
        );
      END
    `);

        await pool.close();

        console.log('Database and tables initialized successfully');
    } catch (err) {
        console.error('Database initialization error:', err);
        process.exit(1);
    }
}

// API endpoint to handle direct JSON data import
app.post('/api/importData', async (req, res) => {
    try {
        const { data } = req.body;

        if (!data || !Array.isArray(data) || data.length === 0) {
            return res.status(400).json({ success: false, error: 'No valid data provided' });
        }

        const result = await importDataToSQL(data);
        res.json(result);
    } catch (error) {
        console.error('Error in /api/importData:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// API endpoint to handle file uploads
app.post('/api/uploadExcel', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, error: 'No file uploaded' });
        }

        // Parse the Excel file
        const workbook = XLSX.readFile(req.file.path, {
            cellDates: true,
            cellStyles: true
        });

        // Get the first sheet
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];

        // Convert to JSON
        const jsonData = XLSX.utils.sheet_to_json(worksheet, {
            raw: false,
            dateNF: 'yyyy-mm-dd HH:mm:ss'
        });

        if (!jsonData || jsonData.length === 0) {
            return res.status(400).json({ success: false, error: 'No data found in the Excel file' });
        }

        // Import data to SQL Server
        const result = await importDataToSQL(jsonData);

        // Delete the temporary file
        fs.unlinkSync(req.file.path);

        res.json(result);
    } catch (error) {
        console.error('Error in /api/uploadExcel:', error);

        // Clean up the file if it exists
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }

        res.status(500).json({ success: false, error: error.message });
    }
});

// Function to import data to SQL Server
async function importDataToSQL(data) {
    let pool;

    try {
        // Connect to the database
        pool = await sql.connect(dbConfig);

        // Create a transaction for better performance and reliability
        const transaction = new sql.Transaction(pool);
        await transaction.begin();

        try {
            // Prepare a request object
            const request = new sql.Request(transaction);
            let rowsInserted = 0;
            let rowsSkipped = 0;
            let errors = [];

            // Process each record
            for (const record of data) {
                try {
                    // Check if record already exists
                    const checkResult = await request.query(`
            SELECT COUNT(*) as count FROM ChangeData 
            WHERE ChangeID = '${record.ChangeID}'
          `);

                    if (checkResult.recordset[0].count > 0) {
                        rowsSkipped++;
                        continue; // Skip existing records
                    }

                    // Build the query dynamically based on available fields
                    let columns = [];
                    let values = [];
                    let params = {};

                    // Map each field from the record to SQL parameters
                    Object.keys(record).forEach(key => {
                        if (record[key] !== undefined && record[key] !== null) {
                            // Convert column names to match SQL table
                            let sqlColumn = key;
                            columns.push(`[${sqlColumn}]`);

                            // Create a parameter name
                            const paramName = `@${key.replace(/\s+/g, '_')}`;
                            values.push(paramName);

                            // Add parameter to the request
                            params[paramName] = record[key];
                        }
                    });

                    if (columns.length === 0) {
                        rowsSkipped++;
                        continue; // Skip empty records
                    }

                    // Build the SQL query
                    const query = `
            INSERT INTO ChangeData (${columns.join(', ')})
            VALUES (${values.join(', ')})
          `;

                    // Add all parameters to the request
                    Object.keys(params).forEach(param => {
                        request.input(param.substring(1), params[param]);
                    });

                    // Execute the query
                    await request.query(query);
                    rowsInserted++;

                    // Clear input parameters for the next query
                    request.parameters = {};
                } catch (recordError) {
                    errors.push({
                        record: record.ChangeID || 'unknown',
                        error: recordError.message
                    });
                }
            }

            // Commit the transaction
            await transaction.commit();

            return {
                success: true,
                rowsInserted,
                rowsSkipped,
                errors: errors.length > 0 ? errors : undefined
            };
        } catch (transactionError) {
            // Roll back the transaction on error
            await transaction.rollback();
            console.error('Transaction error:', transactionError);
            return {
                success: false,
                error: transactionError.message
            };
        }
    } catch (connectionError) {
        console.error('Database connection error:', connectionError);
        return {
            success: false,
            error: connectionError.message
        };
    } finally {
        // Close the pool
        if (pool) {
            pool.close();
        }
    }
}

// API endpoint to get data (for testing)
app.get('/api/getData', async (req, res) => {
    try {
        const pool = await sql.connect(dbConfig);
        const result = await pool.request().query('SELECT TOP 100 * FROM ChangeData');
        pool.close();

        res.json({
            success: true,
            total: result.recordset.length,
            data: result.recordset
        });
    } catch (error) {
        console.error('Error fetching data:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Add a health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({ status: 'UP', timestamp: new Date() });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({
        success: false,
        error: err.message || 'Internal Server Error'
    });
});

// Initialize database and start server
initDatabase()
    .then(() => {
        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
            console.log(`http://localhost:${PORT}`);
        });
    })
    .catch(err => {
        console.error('Failed to start server:', err);
    });